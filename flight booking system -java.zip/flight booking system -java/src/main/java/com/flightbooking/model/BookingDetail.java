package com.flightbooking.model;

public class BookingDetail {

    private int detailId;
    private int bookingId;
    private int flightId;
    private int legOrder;
    private Flight flight;

    public BookingDetail() {}

    public int getDetailId() { return detailId; }
    public void setDetailId(int detailId) { this.detailId = detailId; }
    public int getBookingId() { return bookingId; }
    public void setBookingId(int bookingId) { this.bookingId = bookingId; }
    public int getFlightId() { return flightId; }
    public void setFlightId(int flightId) { this.flightId = flightId; }
    public int getLegOrder() { return legOrder; }
    public void setLegOrder(int legOrder) { this.legOrder = legOrder; }
    public Flight getFlight() { return flight; }
    public void setFlight(Flight flight) { this.flight = flight; }
}
