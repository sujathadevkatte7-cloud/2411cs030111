package com.flightbooking.controller;

import com.flightbooking.dao.FlightDAO;
import com.flightbooking.model.Flight;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.Duration;
import java.util.*;

@RestController
@RequestMapping("/api/flights")
public class FlightController {

    @Autowired
    private FlightDAO flightDAO;

    @GetMapping("/search")
    public ResponseEntity<Map<String, Object>> search(
            @RequestParam String source,
            @RequestParam String destination,
            @RequestParam String date,
            @RequestParam(defaultValue = "false") boolean connecting) {

        List<Map<String, Object>> results = new ArrayList<>();

        List<Flight> directFlights = flightDAO.searchDirect(source, destination, date);
        for (Flight f : directFlights) {
            Map<String, Object> item = new LinkedHashMap<>();
            item.put("type", "DIRECT");
            item.put("flights", List.of(flightToMap(f)));
            item.put("totalFare", f.getEffectivePrice());
            long durationMinutes = Duration.between(f.getDepartureTime(), f.getArrivalTime()).toMinutes();
            item.put("durationMinutes", durationMinutes);
            item.put("durationFormatted", formatDuration(durationMinutes));
            results.add(item);
        }

        if (connecting) {
            List<Map<String, Object>> connectingResults = flightDAO.searchConnecting(source, destination, date);
            results.addAll(connectingResults);
        }

        Map<String, Object> response = new LinkedHashMap<>();
        response.put("source", source);
        response.put("destination", destination);
        response.put("date", date);
        response.put("totalResults", results.size());
        response.put("results", results);
        return ResponseEntity.ok(response);
    }

    private Map<String, Object> flightToMap(Flight f) {
        Map<String, Object> map = new LinkedHashMap<>();
        map.put("flightId", f.getFlightId());
        map.put("flightNumber", f.getFlightNumber());
        map.put("airline", f.getAirline());
        map.put("source", f.getSource());
        map.put("destination", f.getDestination());
        map.put("departureTime", f.getDepartureTime().toString());
        map.put("arrivalTime", f.getArrivalTime().toString());
        map.put("totalSeats", f.getTotalSeats());
        map.put("availableSeats", f.getAvailableSeats());
        map.put("basePrice", f.getBasePrice());
        map.put("effectivePrice", f.getEffectivePrice());
        long durationMinutes = Duration.between(f.getDepartureTime(), f.getArrivalTime()).toMinutes();
        map.put("durationMinutes", durationMinutes);
        map.put("durationFormatted", formatDuration(durationMinutes));
        return map;
    }

    private String formatDuration(long minutes) {
        long h = minutes / 60;
        long m = minutes % 60;
        if (h > 0) return h + "h " + m + "m";
        return m + "m";
    }
}
