package com.flightbooking.controller;

import com.flightbooking.config.SessionManager;
import com.flightbooking.dao.UserDAO;
import com.flightbooking.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.LinkedHashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired
    private UserDAO userDAO;

    @Autowired
    private SessionManager sessionManager;

    @PostMapping("/register")
    public ResponseEntity<Map<String, Object>> register(@RequestBody Map<String, String> body) {
        String name = body.get("name");
        String email = body.get("email");
        String password = body.get("password");

        if (name == null || email == null || password == null ||
                name.isBlank() || email.isBlank() || password.isBlank()) {
            Map<String, Object> error = new LinkedHashMap<>();
            error.put("error", "All fields are required");
            return ResponseEntity.badRequest().body(error);
        }

        User user = userDAO.register(name, email, password);
        if (user == null) {
            Map<String, Object> error = new LinkedHashMap<>();
            error.put("error", "Email already registered");
            return ResponseEntity.badRequest().body(error);
        }

        String token = sessionManager.createSession(user.getUserId());

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("token", token);
        result.put("user", userToMap(user));
        return ResponseEntity.ok(result);
    }

    @PostMapping("/login")
    public ResponseEntity<Map<String, Object>> login(@RequestBody Map<String, String> body) {
        String email = body.get("email");
        String password = body.get("password");

        if (email == null || password == null || email.isBlank() || password.isBlank()) {
            Map<String, Object> error = new LinkedHashMap<>();
            error.put("error", "Email and password are required");
            return ResponseEntity.badRequest().body(error);
        }

        User user = userDAO.login(email, password);
        if (user == null) {
            Map<String, Object> error = new LinkedHashMap<>();
            error.put("error", "Invalid email or password");
            return ResponseEntity.status(401).body(error);
        }

        String token = sessionManager.createSession(user.getUserId());

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("token", token);
        result.put("user", userToMap(user));
        return ResponseEntity.ok(result);
    }

    @PostMapping("/logout")
    public ResponseEntity<Map<String, Object>> logout(@RequestHeader(value = "Authorization", required = false) String auth) {
        if (auth != null && auth.startsWith("Bearer ")) {
            sessionManager.invalidate(auth.substring(7));
        }
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("message", "Logged out successfully");
        return ResponseEntity.ok(result);
    }

    private Map<String, Object> userToMap(User user) {
        Map<String, Object> map = new LinkedHashMap<>();
        map.put("userId", user.getUserId());
        map.put("name", user.getName());
        map.put("email", user.getEmail());
        map.put("role", user.getRole());
        return map;
    }
}
