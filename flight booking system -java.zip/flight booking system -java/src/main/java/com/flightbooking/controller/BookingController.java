package com.flightbooking.controller;

import com.flightbooking.config.SessionManager;
import com.flightbooking.dao.BookingDAO;
import com.flightbooking.model.Booking;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/bookings")
public class BookingController {

    @Autowired
    private BookingDAO bookingDAO;

    @Autowired
    private SessionManager sessionManager;

    @PostMapping
    public ResponseEntity<Map<String, Object>> createBooking(
            @RequestHeader(value = "Authorization", required = false) String auth,
            @RequestBody Map<String, Object> body) {

        Integer userId = sessionManager.extractUserId(auth);
        if (userId == null) {
            Map<String, Object> error = new LinkedHashMap<>();
            error.put("error", "Unauthorized. Please login first.");
            return ResponseEntity.status(401).body(error);
        }

        @SuppressWarnings("unchecked")
        List<Integer> flightIds = (List<Integer>) body.get("flightIds");
        String passengerName = (String) body.get("passengerName");
        String passengerPhone = (String) body.get("passengerPhone");

        if (flightIds == null || flightIds.isEmpty() || passengerName == null || passengerPhone == null) {
            Map<String, Object> error = new LinkedHashMap<>();
            error.put("error", "Flight IDs, passenger name, and phone are required");
            return ResponseEntity.badRequest().body(error);
        }

        Map<String, Object> result = bookingDAO.createBooking(userId, flightIds, passengerName, passengerPhone);
        if (result.containsKey("error")) {
            return ResponseEntity.badRequest().body(result);
        }
        return ResponseEntity.ok(result);
    }

    @GetMapping
    public ResponseEntity<?> getUserBookings(
            @RequestHeader(value = "Authorization", required = false) String auth) {

        Integer userId = sessionManager.extractUserId(auth);
        if (userId == null) {
            Map<String, Object> error = new LinkedHashMap<>();
            error.put("error", "Unauthorized. Please login first.");
            return ResponseEntity.status(401).body(error);
        }

        List<Booking> bookings = bookingDAO.getUserBookings(userId);
        return ResponseEntity.ok(bookings);
    }

    @PutMapping("/{id}/cancel")
    public ResponseEntity<Map<String, Object>> cancelBooking(
            @PathVariable("id") int bookingId,
            @RequestHeader(value = "Authorization", required = false) String auth) {

        Integer userId = sessionManager.extractUserId(auth);
        if (userId == null) {
            Map<String, Object> error = new LinkedHashMap<>();
            error.put("error", "Unauthorized. Please login first.");
            return ResponseEntity.status(401).body(error);
        }

        Map<String, Object> result = bookingDAO.cancelBooking(bookingId, userId);
        if (result.containsKey("error")) {
            return ResponseEntity.badRequest().body(result);
        }
        return ResponseEntity.ok(result);
    }
}
