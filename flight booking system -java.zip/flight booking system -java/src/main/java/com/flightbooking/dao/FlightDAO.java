package com.flightbooking.dao;

import com.flightbooking.model.Flight;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.*;

@Repository
public class FlightDAO {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    private final RowMapper<Flight> flightMapper = (rs, rowNum) -> mapFlight(rs, "");

    private Flight mapFlight(ResultSet rs, String prefix) throws SQLException {
        Flight f = new Flight();
        f.setFlightId(rs.getInt(prefix + "flight_id"));
        f.setFlightNumber(rs.getString(prefix + "flight_number"));
        f.setAirline(rs.getString(prefix + "airline"));
        f.setSource(rs.getString(prefix + "source"));
        f.setDestination(rs.getString(prefix + "destination"));
        f.setDepartureTime(rs.getTimestamp(prefix + "departure_time").toLocalDateTime());
        f.setArrivalTime(rs.getTimestamp(prefix + "arrival_time").toLocalDateTime());
        f.setTotalSeats(rs.getInt(prefix + "total_seats"));
        f.setAvailableSeats(rs.getInt(prefix + "available_seats"));
        f.setBasePrice(rs.getBigDecimal(prefix + "base_price"));
        f.setEffectivePrice(calculateEffectivePrice(f));
        return f;
    }

    public BigDecimal calculateEffectivePrice(Flight f) {
        double ratio = (double) f.getAvailableSeats() / f.getTotalSeats();
        if (ratio < 0.20) {
            return f.getBasePrice().multiply(new BigDecimal("1.10")).setScale(2, RoundingMode.HALF_UP);
        }
        return f.getBasePrice();
    }

    public List<Flight> searchDirect(String source, String destination, String date) {
        String sql = "SELECT * FROM flights WHERE source = ? AND destination = ? AND DATE(departure_time) = ? AND available_seats > 0 ORDER BY departure_time";
        List<Flight> flights = jdbcTemplate.query(sql, flightMapper, source, destination, date);
        return flights;
    }

    public List<Map<String, Object>> searchConnecting(String source, String destination, String date) {
        String sql = "SELECT " +
                "f1.flight_id AS f1_flight_id, f1.flight_number AS f1_flight_number, f1.airline AS f1_airline, " +
                "f1.source AS f1_source, f1.destination AS f1_destination, " +
                "f1.departure_time AS f1_departure_time, f1.arrival_time AS f1_arrival_time, " +
                "f1.total_seats AS f1_total_seats, f1.available_seats AS f1_available_seats, f1.base_price AS f1_base_price, " +
                "f2.flight_id AS f2_flight_id, f2.flight_number AS f2_flight_number, f2.airline AS f2_airline, " +
                "f2.source AS f2_source, f2.destination AS f2_destination, " +
                "f2.departure_time AS f2_departure_time, f2.arrival_time AS f2_arrival_time, " +
                "f2.total_seats AS f2_total_seats, f2.available_seats AS f2_available_seats, f2.base_price AS f2_base_price " +
                "FROM flights f1 " +
                "JOIN flights f2 ON f1.destination = f2.source " +
                "WHERE f1.source = ? AND f2.destination = ? " +
                "AND DATE(f1.departure_time) = ? " +
                "AND f2.departure_time >= DATE_ADD(f1.arrival_time, INTERVAL 90 MINUTE) " +
                "AND f2.departure_time <= DATE_ADD(f1.arrival_time, INTERVAL 12 HOUR) " +
                "AND f1.available_seats > 0 AND f2.available_seats > 0 " +
                "ORDER BY TIMESTAMPDIFF(MINUTE, f1.departure_time, f2.arrival_time) ASC";

        return jdbcTemplate.query(sql, (rs, rowNum) -> {
            Flight f1 = new Flight();
            f1.setFlightId(rs.getInt("f1_flight_id"));
            f1.setFlightNumber(rs.getString("f1_flight_number"));
            f1.setAirline(rs.getString("f1_airline"));
            f1.setSource(rs.getString("f1_source"));
            f1.setDestination(rs.getString("f1_destination"));
            f1.setDepartureTime(rs.getTimestamp("f1_departure_time").toLocalDateTime());
            f1.setArrivalTime(rs.getTimestamp("f1_arrival_time").toLocalDateTime());
            f1.setTotalSeats(rs.getInt("f1_total_seats"));
            f1.setAvailableSeats(rs.getInt("f1_available_seats"));
            f1.setBasePrice(rs.getBigDecimal("f1_base_price"));
            f1.setEffectivePrice(calculateEffectivePrice(f1));

            Flight f2 = new Flight();
            f2.setFlightId(rs.getInt("f2_flight_id"));
            f2.setFlightNumber(rs.getString("f2_flight_number"));
            f2.setAirline(rs.getString("f2_airline"));
            f2.setSource(rs.getString("f2_source"));
            f2.setDestination(rs.getString("f2_destination"));
            f2.setDepartureTime(rs.getTimestamp("f2_departure_time").toLocalDateTime());
            f2.setArrivalTime(rs.getTimestamp("f2_arrival_time").toLocalDateTime());
            f2.setTotalSeats(rs.getInt("f2_total_seats"));
            f2.setAvailableSeats(rs.getInt("f2_available_seats"));
            f2.setBasePrice(rs.getBigDecimal("f2_base_price"));
            f2.setEffectivePrice(calculateEffectivePrice(f2));

            long waitMinutes = Duration.between(f1.getArrivalTime(), f2.getDepartureTime()).toMinutes();

            Map<String, Object> result = new LinkedHashMap<>();
            result.put("type", "CONNECTING");
            result.put("leg1", f1);
            result.put("leg2", f2);
            result.put("layoverAirport", f1.getDestination());
            result.put("waitTimeMinutes", waitMinutes);
            result.put("waitTimeFormatted", formatDuration(waitMinutes));
            result.put("totalFare", f1.getEffectivePrice().add(f2.getEffectivePrice()));
            return result;
        }, source, destination, date);
    }

    public Flight findById(int flightId) {
        return jdbcTemplate.queryForObject("SELECT * FROM flights WHERE flight_id = ?", flightMapper, flightId);
    }

    private String formatDuration(long minutes) {
        long h = minutes / 60;
        long m = minutes % 60;
        if (h > 0) return h + "h " + m + "m";
        return m + "m";
    }
}
