package com.flightbooking.dao;

import com.flightbooking.model.Booking;
import com.flightbooking.model.BookingDetail;
import com.flightbooking.model.Flight;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.util.*;

@Repository
public class BookingDAO {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    private FlightDAO flightDAO;

    @Transactional
    public Map<String, Object> createBooking(int userId, List<Integer> flightIds, String passengerName, String passengerPhone) {
        BigDecimal totalFare = BigDecimal.ZERO;
        List<Flight> flights = new ArrayList<>();

        for (int fid : flightIds) {
            Flight f = flightDAO.findById(fid);
            if (f == null || f.getAvailableSeats() <= 0) {
                Map<String, Object> error = new HashMap<>();
                error.put("error", "Flight " + fid + " is not available");
                return error;
            }
            flights.add(f);
            totalFare = totalFare.add(flightDAO.calculateEffectivePrice(f));
        }

        String pnr = generatePNR();

        KeyHolder keyHolder = new GeneratedKeyHolder();
        BigDecimal finalTotalFare = totalFare;
        jdbcTemplate.update(connection -> {
            PreparedStatement ps = connection.prepareStatement(
                    "INSERT INTO bookings (user_id, pnr, passenger_name, passenger_phone, booking_date, total_fare, status) VALUES (?, ?, ?, ?, ?, ?, 'CONFIRMED')",
                    Statement.RETURN_GENERATED_KEYS);
            ps.setInt(1, userId);
            ps.setString(2, pnr);
            ps.setString(3, passengerName);
            ps.setString(4, passengerPhone);
            ps.setObject(5, LocalDateTime.now());
            ps.setBigDecimal(6, finalTotalFare);
            return ps;
        }, keyHolder);

        int bookingId = keyHolder.getKey().intValue();

        for (int i = 0; i < flights.size(); i++) {
            Flight f = flights.get(i);
            jdbcTemplate.update(
                    "INSERT INTO booking_details (booking_id, flight_id, leg_order) VALUES (?, ?, ?)",
                    bookingId, f.getFlightId(), i + 1);
            jdbcTemplate.update(
                    "UPDATE flights SET available_seats = available_seats - 1 WHERE flight_id = ? AND available_seats > 0",
                    f.getFlightId());
        }

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("bookingId", bookingId);
        result.put("pnr", pnr);
        result.put("totalFare", totalFare);
        result.put("status", "CONFIRMED");
        result.put("passengerName", passengerName);
        return result;
    }

    @Transactional
    public Map<String, Object> cancelBooking(int bookingId, int userId) {
        List<Map<String, Object>> rows = jdbcTemplate.queryForList(
                "SELECT * FROM bookings WHERE booking_id = ? AND user_id = ?", bookingId, userId);

        if (rows.isEmpty()) {
            Map<String, Object> error = new HashMap<>();
            error.put("error", "Booking not found or access denied");
            return error;
        }

        String status = (String) rows.get(0).get("status");
        if ("CANCELLED".equals(status)) {
            Map<String, Object> error = new HashMap<>();
            error.put("error", "Booking is already cancelled");
            return error;
        }

        List<Map<String, Object>> details = jdbcTemplate.queryForList(
                "SELECT flight_id FROM booking_details WHERE booking_id = ?", bookingId);

        for (Map<String, Object> detail : details) {
            int flightId = (int) detail.get("flight_id");
            jdbcTemplate.update(
                    "UPDATE flights SET available_seats = available_seats + 1 WHERE flight_id = ?", flightId);
        }

        jdbcTemplate.update(
                "UPDATE bookings SET status = 'CANCELLED' WHERE booking_id = ?", bookingId);

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("bookingId", bookingId);
        result.put("status", "CANCELLED");
        result.put("message", "Booking cancelled successfully");
        return result;
    }

    public List<Booking> getUserBookings(int userId) {
        String sql = "SELECT b.booking_id, b.user_id, b.pnr, b.passenger_name, b.passenger_phone, " +
                "b.booking_date, b.total_fare, b.status, " +
                "bd.detail_id, bd.leg_order, " +
                "f.flight_id, f.flight_number, f.airline, f.source, f.destination, " +
                "f.departure_time, f.arrival_time, f.total_seats, f.available_seats, f.base_price " +
                "FROM bookings b " +
                "JOIN booking_details bd ON b.booking_id = bd.booking_id " +
                "JOIN flights f ON bd.flight_id = f.flight_id " +
                "WHERE b.user_id = ? " +
                "ORDER BY b.booking_date DESC, bd.leg_order ASC";

        Map<Integer, Booking> bookingMap = new LinkedHashMap<>();

        jdbcTemplate.query(sql, (rs) -> {
            int bid = rs.getInt("booking_id");
            Booking booking = bookingMap.get(bid);
            if (booking == null) {
                booking = new Booking();
                booking.setBookingId(bid);
                booking.setUserId(rs.getInt("user_id"));
                booking.setPnr(rs.getString("pnr"));
                booking.setPassengerName(rs.getString("passenger_name"));
                booking.setPassengerPhone(rs.getString("passenger_phone"));
                booking.setBookingDate(rs.getTimestamp("booking_date").toLocalDateTime());
                booking.setTotalFare(rs.getBigDecimal("total_fare"));
                booking.setStatus(rs.getString("status"));
                bookingMap.put(bid, booking);
            }

            BookingDetail detail = new BookingDetail();
            detail.setDetailId(rs.getInt("detail_id"));
            detail.setBookingId(bid);
            detail.setFlightId(rs.getInt("flight_id"));
            detail.setLegOrder(rs.getInt("leg_order"));

            Flight flight = new Flight();
            flight.setFlightId(rs.getInt("flight_id"));
            flight.setFlightNumber(rs.getString("flight_number"));
            flight.setAirline(rs.getString("airline"));
            flight.setSource(rs.getString("source"));
            flight.setDestination(rs.getString("destination"));
            flight.setDepartureTime(rs.getTimestamp("departure_time").toLocalDateTime());
            flight.setArrivalTime(rs.getTimestamp("arrival_time").toLocalDateTime());
            flight.setTotalSeats(rs.getInt("total_seats"));
            flight.setAvailableSeats(rs.getInt("available_seats"));
            flight.setBasePrice(rs.getBigDecimal("base_price"));
            flight.setEffectivePrice(flightDAO.calculateEffectivePrice(flight));
            detail.setFlight(flight);

            booking.getDetails().add(detail);
        }, userId);

        return new ArrayList<>(bookingMap.values());
    }

    private String generatePNR() {
        String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        Random random = new Random();
        for (int attempt = 0; attempt < 10; attempt++) {
            StringBuilder pnr = new StringBuilder();
            for (int i = 0; i < 6; i++) {
                pnr.append(chars.charAt(random.nextInt(chars.length())));
            }
            String candidate = pnr.toString();
            List<Map<String, Object>> existing = jdbcTemplate.queryForList(
                    "SELECT booking_id FROM bookings WHERE pnr = ?", candidate);
            if (existing.isEmpty()) {
                return candidate;
            }
        }
        return UUID.randomUUID().toString().substring(0, 8).toUpperCase();
    }
}
