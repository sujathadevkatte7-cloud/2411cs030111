const API = '';

const CITIES = {
    'DEL': 'New Delhi',
    'BOM': 'Mumbai',
    'BLR': 'Bengaluru',
    'HYD': 'Hyderabad',
    'CCU': 'Kolkata',
    'MAA': 'Chennai'
};

function getToken() {
    return localStorage.getItem('sv_token');
}

function getUser() {
    const u = localStorage.getItem('sv_user');
    return u ? JSON.parse(u) : null;
}

function setSession(token, user) {
    localStorage.setItem('sv_token', token);
    localStorage.setItem('sv_user', JSON.stringify(user));
}

function clearSession() {
    localStorage.removeItem('sv_token');
    localStorage.removeItem('sv_user');
}

async function apiCall(url, options = {}) {
    const token = getToken();
    const headers = { 'Content-Type': 'application/json', ...(options.headers || {}) };
    if (token) headers['Authorization'] = 'Bearer ' + token;
    options.headers = headers;
    const res = await fetch(API + url, options);
    return res.json();
}

function showToast(msg, type = '') {
    let t = document.getElementById('toast');
    if (!t) {
        t = document.createElement('div');
        t.id = 'toast';
        t.className = 'toast';
        document.body.appendChild(t);
    }
    t.textContent = msg;
    t.className = 'toast ' + type;
    setTimeout(() => t.classList.add('show'), 10);
    setTimeout(() => t.classList.remove('show'), 3500);
}

function renderNav() {
    const container = document.getElementById('nav-container');
    if (!container) return;
    const user = getUser();
    container.innerHTML = `
        <nav class="navbar">
            <a href="index.html" class="nav-brand">✈ Sky<span>Voyage</span></a>
            <div class="nav-links">
                <a href="index.html">Home</a>
                ${user ? `
                    <a href="bookings.html">My Bookings</a>
                    <span class="nav-user">Hi, ${user.name}</span>
                    <button class="btn-nav btn-nav-outline" onclick="logout()">Logout</button>
                ` : `
                    <a href="login.html" class="btn-nav btn-nav-outline">Login</a>
                    <a href="register.html" class="btn-nav">Register</a>
                `}
            </div>
        </nav>
    `;
}

async function logout() {
    await apiCall('/api/auth/logout', { method: 'POST' });
    clearSession();
    window.location.href = 'index.html';
}

function cityName(code) {
    return CITIES[code] || code;
}

function formatTime(dtStr) {
    const d = new Date(dtStr);
    return d.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', hour12: true });
}

function formatDate(dtStr) {
    const d = new Date(dtStr);
    return d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
}

function formatCurrency(amount) {
    return '₹' + Number(amount).toLocaleString('en-IN', { minimumFractionDigits: 0, maximumFractionDigits: 0 });
}

function populateCityDropdowns() {
    const selects = document.querySelectorAll('.city-select');
    selects.forEach(sel => {
        sel.innerHTML = '<option value="">Select City</option>';
        Object.entries(CITIES).forEach(([code, name]) => {
            sel.innerHTML += `<option value="${code}">${name} (${code})</option>`;
        });
    });
}

function initHome() {
    renderNav();
    populateCityDropdowns();
    createParticles();

    const dateInput = document.getElementById('travel-date');
    if (dateInput) {
        const tomorrow = new Date();
        tomorrow.setDate(tomorrow.getDate() + 1);
        dateInput.min = tomorrow.toISOString().split('T')[0];
        dateInput.value = '2026-07-15';
    }

    const form = document.getElementById('search-form');
    if (form) {
        form.addEventListener('submit', function (e) {
            e.preventDefault();
            const source = document.getElementById('source').value;
            const destination = document.getElementById('destination').value;
            const date = document.getElementById('travel-date').value;
            const connecting = document.getElementById('connecting-toggle').checked;

            if (!source || !destination || !date) {
                showToast('Please fill all search fields', 'error');
                return;
            }
            if (source === destination) {
                showToast('Source and destination cannot be the same', 'error');
                return;
            }

            window.location.href = `results.html?source=${source}&destination=${destination}&date=${date}&connecting=${connecting}`;
        });
    }
}

function createParticles() {
    const container = document.querySelector('.hero-particles');
    if (!container) return;
    for (let i = 0; i < 30; i++) {
        const p = document.createElement('div');
        p.className = 'particle';
        p.style.left = Math.random() * 100 + '%';
        p.style.animationDuration = (8 + Math.random() * 12) + 's';
        p.style.animationDelay = (Math.random() * 10) + 's';
        p.style.width = (2 + Math.random() * 4) + 'px';
        p.style.height = p.style.width;
        container.appendChild(p);
    }
}

function swapCities() {
    const s = document.getElementById('source');
    const d = document.getElementById('destination');
    if (s && d) {
        const tmp = s.value;
        s.value = d.value;
        d.value = tmp;
    }
}

async function initResults() {
    renderNav();
    const params = new URLSearchParams(window.location.search);
    const source = params.get('source');
    const destination = params.get('destination');
    const date = params.get('date');
    const connecting = params.get('connecting') === 'true';

    const summary = document.getElementById('search-summary');
    if (summary) {
        summary.textContent = `${cityName(source)} (${source}) → ${cityName(destination)} (${destination}) | ${formatDate(date + 'T00:00:00')}`;
    }

    const loader = document.getElementById('results-loader');
    const list = document.getElementById('results-list');
    if (loader) loader.classList.add('active');

    const data = await apiCall(`/api/flights/search?source=${source}&destination=${destination}&date=${date}&connecting=${connecting}`);

    if (loader) loader.classList.remove('active');

    if (!data.results || data.results.length === 0) {
        list.innerHTML = `
            <div class="no-results">
                <div class="no-icon">✈</div>
                <h2>No flights found</h2>
                <p>Try different dates or enable connecting flights</p>
            </div>`;
        return;
    }

    list.innerHTML = '';
    data.results.forEach(result => {
        if (result.type === 'DIRECT') {
            list.innerHTML += renderDirectCard(result);
        } else {
            list.innerHTML += renderConnectingCard(result);
        }
    });
}

function renderDirectCard(result) {
    const f = result.flights[0];
    const surgeHtml = f.effectivePrice > f.basePrice
        ? `<div class="price-surge">⚡ Surge pricing active</div>` : '';
    return `
        <div class="flight-card">
            <div class="flight-card-header">
                <div class="airline-info">
                    <div class="airline-logo">✈</div>
                    <div>
                        <div class="airline-name">${f.airline}</div>
                        <div class="flight-num">${f.flightNumber}</div>
                    </div>
                </div>
                <span class="type-badge type-direct">Direct</span>
            </div>
            <div class="flight-route">
                <div class="route-point">
                    <div class="route-time">${formatTime(f.departureTime)}</div>
                    <div class="route-city">${cityName(f.source)} (${f.source})</div>
                </div>
                <div class="route-line">
                    <span class="duration">${f.durationFormatted}</span>
                    <span class="plane-icon">✈</span>
                </div>
                <div class="route-point">
                    <div class="route-time">${formatTime(f.arrivalTime)}</div>
                    <div class="route-city">${cityName(f.destination)} (${f.destination})</div>
                </div>
            </div>
            <div class="flight-card-footer">
                <div class="flight-meta">
                    <div class="meta-item"><strong>${f.availableSeats}</strong> seats left</div>
                    <div class="meta-item">${formatDate(f.departureTime)}</div>
                </div>
                <div class="price-tag">
                    <div class="price-amount">${formatCurrency(result.totalFare)}</div>
                    <div class="price-label">per person</div>
                    ${surgeHtml}
                </div>
                <button class="btn-secondary" onclick='openBookingModal(${JSON.stringify([f.flightId])}, ${result.totalFare}, "DIRECT", ${JSON.stringify(f)})'>Book Now</button>
            </div>
        </div>`;
}

function renderConnectingCard(result) {
    const f1 = result.leg1;
    const f2 = result.leg2;
    return `
        <div class="flight-card">
            <div class="flight-card-header">
                <div class="airline-info">
                    <div class="airline-logo">🔗</div>
                    <div>
                        <div class="airline-name">${f1.airline} + ${f2.airline}</div>
                        <div class="flight-num">${f1.flightNumber} → ${f2.flightNumber}</div>
                    </div>
                </div>
                <span class="type-badge type-connecting">Connecting</span>
            </div>
            <div class="connecting-legs">
                <div class="flight-route">
                    <div class="route-point">
                        <div class="route-time">${formatTime(f1.departureTime)}</div>
                        <div class="route-city">${cityName(f1.source)} (${f1.source})</div>
                    </div>
                    <div class="route-line">
                        <span class="duration">${f1.durationFormatted}</span>
                        <span class="plane-icon">✈</span>
                    </div>
                    <div class="route-point">
                        <div class="route-time">${formatTime(f1.arrivalTime)}</div>
                        <div class="route-city">${cityName(f1.destination)} (${f1.destination})</div>
                    </div>
                </div>
                <div class="layover-banner">
                    <span class="layover-icon">⏱</span>
                    <span>${result.waitTimeFormatted} layover at ${cityName(result.layoverAirport)} (${result.layoverAirport})</span>
                </div>
                <div class="flight-route">
                    <div class="route-point">
                        <div class="route-time">${formatTime(f2.departureTime)}</div>
                        <div class="route-city">${cityName(f2.source)} (${f2.source})</div>
                    </div>
                    <div class="route-line">
                        <span class="duration">${f2.durationFormatted}</span>
                        <span class="plane-icon">✈</span>
                    </div>
                    <div class="route-point">
                        <div class="route-time">${formatTime(f2.arrivalTime)}</div>
                        <div class="route-city">${cityName(f2.destination)} (${f2.destination})</div>
                    </div>
                </div>
            </div>
            <div class="flight-card-footer">
                <div class="flight-meta">
                    <div class="meta-item"><strong>${Math.min(f1.availableSeats, f2.availableSeats)}</strong> seats left</div>
                    <div class="meta-item">${formatDate(f1.departureTime)}</div>
                </div>
                <div class="price-tag">
                    <div class="price-amount">${formatCurrency(result.totalFare)}</div>
                    <div class="price-label">total for both legs</div>
                </div>
                <button class="btn-secondary" onclick='openBookingModal(${JSON.stringify([f1.flightId, f2.flightId])}, ${result.totalFare}, "CONNECTING", null, ${JSON.stringify(f1)}, ${JSON.stringify(f2)})'>Book Now</button>
            </div>
        </div>`;
}

let currentBookingData = {};

function openBookingModal(flightIds, totalFare, type, directFlight, leg1, leg2) {
    const user = getUser();
    if (!user) {
        showToast('Please login to book a flight', 'error');
        setTimeout(() => window.location.href = 'login.html', 1500);
        return;
    }

    currentBookingData = { flightIds, totalFare, type };

    const modal = document.getElementById('booking-modal');
    const nameInput = document.getElementById('passenger-name');
    const fareBreakdown = document.getElementById('fare-breakdown');

    if (nameInput) nameInput.value = user.name;

    let fareHtml = '';
    if (type === 'DIRECT' && directFlight) {
        fareHtml = `
            <div class="fare-row"><span>${directFlight.airline} ${directFlight.flightNumber}</span><span>${formatCurrency(directFlight.effectivePrice)}</span></div>
            <div class="fare-row total"><span>Total</span><span>${formatCurrency(totalFare)}</span></div>`;
    } else if (leg1 && leg2) {
        fareHtml = `
            <div class="fare-row"><span>Leg 1: ${leg1.airline} ${leg1.flightNumber}</span><span>${formatCurrency(leg1.effectivePrice)}</span></div>
            <div class="fare-row"><span>Leg 2: ${leg2.airline} ${leg2.flightNumber}</span><span>${formatCurrency(leg2.effectivePrice)}</span></div>
            <div class="fare-row total"><span>Total</span><span>${formatCurrency(totalFare)}</span></div>`;
    }
    if (fareBreakdown) fareBreakdown.innerHTML = fareHtml;

    if (modal) modal.classList.add('active');
}

function closeBookingModal() {
    const modal = document.getElementById('booking-modal');
    if (modal) modal.classList.remove('active');
}

function closeSuccessModal() {
    const modal = document.getElementById('success-modal');
    if (modal) modal.classList.remove('active');
}

async function submitBooking(e) {
    e.preventDefault();
    const name = document.getElementById('passenger-name').value.trim();
    const phone = document.getElementById('passenger-phone').value.trim();

    if (!name || !phone) {
        showToast('Please fill all fields', 'error');
        return;
    }

    const data = await apiCall('/api/bookings', {
        method: 'POST',
        body: JSON.stringify({
            flightIds: currentBookingData.flightIds,
            passengerName: name,
            passengerPhone: phone
        })
    });

    if (data.error) {
        showToast(data.error, 'error');
        return;
    }

    closeBookingModal();

    const successModal = document.getElementById('success-modal');
    const pnrDisplay = document.getElementById('pnr-display');
    if (pnrDisplay) pnrDisplay.textContent = data.pnr;
    if (successModal) successModal.classList.add('active');
}

async function initBookings() {
    renderNav();

    const user = getUser();
    if (!user) {
        window.location.href = 'login.html';
        return;
    }

    const loader = document.getElementById('bookings-loader');
    const list = document.getElementById('bookings-list');

    if (loader) loader.classList.add('active');

    const data = await apiCall('/api/bookings');

    if (loader) loader.classList.remove('active');

    if (!Array.isArray(data) || data.length === 0) {
        list.innerHTML = `
            <div class="empty-state">
                <div class="empty-icon">🎫</div>
                <h2>No bookings yet</h2>
                <p>Search for flights and book your first trip!</p>
                <a href="index.html" class="btn-secondary" style="margin-top:20px;display:inline-flex">Search Flights</a>
            </div>`;
        return;
    }

    list.innerHTML = '';
    data.forEach(booking => {
        const isConfirmed = booking.status === 'CONFIRMED';
        let legsHtml = '';
        booking.details.forEach(detail => {
            const f = detail.flight;
            legsHtml += `
                <div class="booking-leg">
                    <span class="leg-label">Leg ${detail.legOrder}</span>
                    <div class="leg-route">
                        <span class="leg-city">${cityName(f.source)} (${f.source})</span>
                        <span class="leg-arrow">→</span>
                        <span class="leg-city">${cityName(f.destination)} (${f.destination})</span>
                    </div>
                    <div class="leg-time">${f.airline} ${f.flightNumber} | ${formatTime(f.departureTime)} - ${formatTime(f.arrivalTime)}</div>
                </div>`;
        });

        list.innerHTML += `
            <div class="booking-card">
                <div class="booking-card-header">
                    <div>
                        <span class="pnr-badge">PNR: ${booking.pnr}</span>
                    </div>
                    <span class="status-badge ${isConfirmed ? 'status-confirmed' : 'status-cancelled'}">${booking.status}</span>
                </div>
                <div class="booking-legs">${legsHtml}</div>
                <div class="booking-card-footer">
                    <div>
                        <div class="booking-fare">${formatCurrency(booking.totalFare)}</div>
                        <div class="booking-date">Booked on ${formatDate(booking.bookingDate)}</div>
                    </div>
                    ${isConfirmed ? `<button class="btn-danger" onclick="cancelBooking(${booking.bookingId})">✕ Cancel Booking</button>` : ''}
                </div>
            </div>`;
    });
}

async function cancelBooking(bookingId) {
    if (!confirm('Are you sure you want to cancel this booking? This action cannot be undone.')) return;

    const data = await apiCall(`/api/bookings/${bookingId}/cancel`, { method: 'PUT' });

    if (data.error) {
        showToast(data.error, 'error');
        return;
    }

    showToast('Booking cancelled successfully', 'success');
    setTimeout(() => initBookings(), 800);
}

async function handleLogin(e) {
    e.preventDefault();
    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value;
    const errorEl = document.getElementById('error-msg');

    const data = await apiCall('/api/auth/login', {
        method: 'POST',
        body: JSON.stringify({ email, password })
    });

    if (data.error) {
        if (errorEl) {
            errorEl.textContent = data.error;
            errorEl.classList.add('show');
        }
        return;
    }

    setSession(data.token, data.user);
    showToast('Welcome back, ' + data.user.name + '!', 'success');
    setTimeout(() => window.location.href = 'index.html', 800);
}

async function handleRegister(e) {
    e.preventDefault();
    const name = document.getElementById('name').value.trim();
    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value;
    const errorEl = document.getElementById('error-msg');

    if (!name || !email || !password) {
        if (errorEl) {
            errorEl.textContent = 'All fields are required';
            errorEl.classList.add('show');
        }
        return;
    }

    const data = await apiCall('/api/auth/register', {
        method: 'POST',
        body: JSON.stringify({ name, email, password })
    });

    if (data.error) {
        if (errorEl) {
            errorEl.textContent = data.error;
            errorEl.classList.add('show');
        }
        return;
    }

    setSession(data.token, data.user);
    showToast('Account created successfully!', 'success');
    setTimeout(() => window.location.href = 'index.html', 800);
}
