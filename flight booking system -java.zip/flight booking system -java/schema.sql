CREATE DATABASE IF NOT EXISTS flight_booking_db;
USE flight_booking_db;

DROP TABLE IF EXISTS booking_details;
DROP TABLE IF EXISTS bookings;
DROP TABLE IF EXISTS flights;
DROP TABLE IF EXISTS users;

CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role VARCHAR(20) DEFAULT 'PASSENGER'
);

CREATE TABLE flights (
    flight_id INT AUTO_INCREMENT PRIMARY KEY,
    flight_number VARCHAR(10) NOT NULL,
    airline VARCHAR(50) NOT NULL,
    source VARCHAR(50) NOT NULL,
    destination VARCHAR(50) NOT NULL,
    departure_time DATETIME NOT NULL,
    arrival_time DATETIME NOT NULL,
    total_seats INT NOT NULL,
    available_seats INT NOT NULL,
    base_price DECIMAL(10,2) NOT NULL
);

CREATE TABLE bookings (
    booking_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    pnr VARCHAR(10) NOT NULL UNIQUE,
    passenger_name VARCHAR(100) NOT NULL,
    passenger_phone VARCHAR(15) NOT NULL,
    booking_date DATETIME NOT NULL,
    total_fare DECIMAL(10,2) NOT NULL,
    status ENUM('CONFIRMED','CANCELLED') DEFAULT 'CONFIRMED',
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

CREATE TABLE booking_details (
    detail_id INT AUTO_INCREMENT PRIMARY KEY,
    booking_id INT NOT NULL,
    flight_id INT NOT NULL,
    leg_order INT NOT NULL,
    FOREIGN KEY (booking_id) REFERENCES bookings(booking_id),
    FOREIGN KEY (flight_id) REFERENCES flights(flight_id)
);

INSERT INTO users (name, email, password, role) VALUES
('Test User', 'test@email.com', 'password123', 'PASSENGER'),
('Admin User', 'admin@email.com', 'admin123', 'ADMIN');

INSERT INTO flights (flight_number, airline, source, destination, departure_time, arrival_time, total_seats, available_seats, base_price) VALUES
('AI-101', 'Air India', 'DEL', 'BOM', '2026-07-15 06:00:00', '2026-07-15 08:15:00', 180, 180, 4500.00),
('AI-102', 'Air India', 'BOM', 'DEL', '2026-07-15 09:30:00', '2026-07-15 11:45:00', 180, 180, 4500.00),
('6E-201', 'IndiGo', 'DEL', 'BLR', '2026-07-15 07:30:00', '2026-07-15 10:15:00', 200, 200, 5800.00),
('6E-202', 'IndiGo', 'BLR', 'DEL', '2026-07-15 11:00:00', '2026-07-15 13:45:00', 200, 200, 5800.00),
('SG-301', 'SpiceJet', 'BOM', 'BLR', '2026-07-15 10:00:00', '2026-07-15 11:45:00', 150, 150, 3800.00),
('SG-302', 'SpiceJet', 'BLR', 'BOM', '2026-07-15 14:00:00', '2026-07-15 15:45:00', 150, 150, 3800.00),
('UK-401', 'Vistara', 'DEL', 'HYD', '2026-07-15 08:00:00', '2026-07-15 10:15:00', 170, 170, 5200.00),
('UK-402', 'Vistara', 'HYD', 'DEL', '2026-07-15 16:00:00', '2026-07-15 18:15:00', 170, 170, 5200.00),
('AI-501', 'Air India', 'HYD', 'BLR', '2026-07-15 12:00:00', '2026-07-15 13:15:00', 160, 160, 3200.00),
('AI-502', 'Air India', 'BLR', 'HYD', '2026-07-15 15:00:00', '2026-07-15 16:15:00', 160, 160, 3200.00),
('6E-601', 'IndiGo', 'CCU', 'DEL', '2026-07-15 05:30:00', '2026-07-15 07:45:00', 190, 190, 5500.00),
('6E-602', 'IndiGo', 'DEL', 'CCU', '2026-07-15 14:00:00', '2026-07-15 16:15:00', 190, 190, 5500.00),
('SG-701', 'SpiceJet', 'MAA', 'BOM', '2026-07-15 06:30:00', '2026-07-15 08:45:00', 160, 160, 4200.00),
('SG-702', 'SpiceJet', 'BOM', 'MAA', '2026-07-15 13:00:00', '2026-07-15 15:15:00', 160, 160, 4200.00),
('UK-801', 'Vistara', 'BLR', 'MAA', '2026-07-15 09:00:00', '2026-07-15 10:00:00', 140, 140, 2500.00),
('UK-802', 'Vistara', 'MAA', 'BLR', '2026-07-15 15:30:00', '2026-07-15 16:30:00', 140, 140, 2500.00),
('AI-901', 'Air India', 'CCU', 'BOM', '2026-07-15 07:00:00', '2026-07-15 09:45:00', 175, 175, 6200.00),
('6E-103', 'IndiGo', 'HYD', 'MAA', '2026-07-15 12:30:00', '2026-07-15 13:45:00', 150, 5, 3000.00),
('AI-103', 'Air India', 'DEL', 'MAA', '2026-07-15 09:00:00', '2026-07-15 12:00:00', 180, 180, 6800.00),
('UK-501', 'Vistara', 'CCU', 'HYD', '2026-07-15 06:00:00', '2026-07-15 08:30:00', 160, 160, 5000.00),
('AI-101', 'Air India', 'DEL', 'BOM', '2026-07-16 06:00:00', '2026-07-16 08:15:00', 180, 180, 4500.00),
('SG-301', 'SpiceJet', 'BOM', 'BLR', '2026-07-16 10:00:00', '2026-07-16 11:45:00', 150, 150, 3800.00),
('UK-401', 'Vistara', 'DEL', 'HYD', '2026-07-16 08:00:00', '2026-07-16 10:15:00', 170, 170, 5200.00),
('AI-501', 'Air India', 'HYD', 'BLR', '2026-07-16 12:00:00', '2026-07-16 13:15:00', 160, 160, 3200.00),
('6E-201', 'IndiGo', 'DEL', 'BLR', '2026-07-16 07:30:00', '2026-07-16 10:15:00', 200, 200, 5800.00),
('SG-702', 'SpiceJet', 'BOM', 'MAA', '2026-07-16 13:00:00', '2026-07-16 15:15:00', 160, 160, 4200.00),
('AI-103', 'Air India', 'DEL', 'MAA', '2026-07-16 09:00:00', '2026-07-16 12:00:00', 180, 180, 6800.00),
('6E-103', 'IndiGo', 'HYD', 'MAA', '2026-07-16 12:30:00', '2026-07-16 13:45:00', 150, 150, 3000.00),
('AI-102', 'Air India', 'BOM', 'DEL', '2026-07-16 09:30:00', '2026-07-16 11:45:00', 180, 180, 4500.00),
('UK-402', 'Vistara', 'HYD', 'DEL', '2026-07-16 16:00:00', '2026-07-16 18:15:00', 170, 170, 5200.00),
('AI-101', 'Air India', 'DEL', 'BOM', '2026-07-17 06:00:00', '2026-07-17 08:15:00', 180, 35, 4500.00),
('6E-201', 'IndiGo', 'DEL', 'BLR', '2026-07-17 07:30:00', '2026-07-17 10:15:00', 200, 200, 5800.00),
('SG-301', 'SpiceJet', 'BOM', 'BLR', '2026-07-17 10:00:00', '2026-07-17 11:45:00', 150, 150, 3800.00),
('UK-401', 'Vistara', 'DEL', 'HYD', '2026-07-17 08:00:00', '2026-07-17 10:15:00', 170, 170, 5200.00),
('AI-501', 'Air India', 'HYD', 'BLR', '2026-07-17 12:00:00', '2026-07-17 13:15:00', 160, 160, 3200.00);
